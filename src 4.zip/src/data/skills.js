export const skills = [
  // Frontend
  { name: 'React',         level: 95, color: '#61dafb', category: 'Frontend' },
  { name: 'TypeScript',    level: 85, color: '#3178c6', category: 'Frontend' },
  { name: 'Next.js',       level: 80, color: '#ffffff', category: 'Frontend' },
  { name: 'Three.js',      level: 75, color: '#ffffff', category: 'Frontend' },
  { name: 'Tailwind CSS',  level: 90, color: '#38bdf8', category: 'Frontend' },
  { name: 'Framer Motion', level: 78, color: '#ff0055', category: 'Frontend' },
  { name: 'HTML5 / CSS3',  level: 95, color: '#e34f26', category: 'Frontend' },

  // Backend
  { name: 'Node.js',       level: 88, color: '#8cc84b', category: 'Backend'  },
  { name: 'Express.js',    level: 85, color: '#ffffff', category: 'Backend'  },
  { name: 'GraphQL',       level: 70, color: '#e10098', category: 'Backend'  },
  { name: 'REST APIs',     level: 92, color: '#00d4ff', category: 'Backend'  },
  { name: 'Redis',         level: 65, color: '#d82c20', category: 'Backend'  },

  // Database
  { name: 'PostgreSQL',    level: 80, color: '#336791', category: 'Database' },
  { name: 'MongoDB',       level: 75, color: '#4db33d', category: 'Database' },
  { name: 'MySQL',         level: 72, color: '#00758f', category: 'Database' },
  { name: 'Prisma ORM',    level: 70, color: '#5a67d8', category: 'Database' },

  // Tools
  { name: 'Git / GitHub',  level: 92, color: '#f05032', category: 'Tools'    },
  { name: 'Docker',        level: 72, color: '#2496ed', category: 'Tools'    },
  { name: 'Figma',         level: 82, color: '#f24e1e', category: 'Tools'    },
  { name: 'VS Code',       level: 95, color: '#007acc', category: 'Tools'    },
  { name: 'Linux',         level: 78, color: '#fcc624', category: 'Tools'    },
  { name: 'Jest / Testing',level: 70, color: '#c21325', category: 'Tools'    },

  // Cloud
  { name: 'AWS',           level: 65, color: '#ff9900', category: 'Cloud'    },
  { name: 'Vercel',        level: 88, color: '#ffffff', category: 'Cloud'    },
  { name: 'Netlify',       level: 82, color: '#00c7b7', category: 'Cloud'    },
  { name: 'Firebase',      level: 70, color: '#ffca28', category: 'Cloud'    },
]

export const skillCategories = ['Frontend', 'Backend', 'Database', 'Tools', 'Cloud']