/**
 * src/data/certifications.js
 *
 * ADD YOUR REAL CERTIFICATIONS HERE.
 * Each entry:
 *   id         — unique number
 *   title      — certificate name
 *   issuer     — who gave it (Coursera, Google, AWS, etc.)
 *   date       — month + year issued
 *   expires    — 'No Expiry' or expiry date string
 *   credentialId — your cert ID (shown on credential, used for verify link)
 *   url        — direct verify / credential link
 *   color      — accent colour for the card
 *   category   — for filtering tabs
 *   skills     — list of skills this cert covers
 *   logo       — issuer logo emoji or icon (replace with real image path if you have it)
 */
export const certifications = [
  {
    id: 1,
    title:        'React — The Complete Guide',
    issuer:       'Udemy',
    date:         'Jan 2024',
    expires:      'No Expiry',
    credentialId: 'UC-XXXXXXXXXXXX',
    url:          'https://udemy.com/certificate/UC-XXXXXXXXXXXX',
    color:        '#61dafb',
    category:     'Frontend',
    skills:       ['React', 'Hooks', 'Redux', 'React Router'],
    logo:         '🎓',
  },
  {
    id: 2,
    title:        'The Web Developer Bootcamp',
    issuer:       'Udemy',
    date:         'Aug 2023',
    expires:      'No Expiry',
    credentialId: 'UC-YYYYYYYYYYYY',
    url:          'https://udemy.com/certificate/UC-YYYYYYYYYYYY',
    color:        '#ff9f43',
    category:     'Full Stack',
    skills:       ['HTML', 'CSS', 'JavaScript', 'Node.js', 'MongoDB'],
    logo:         '🌐',
  },
  {
    id: 3,
    title:        'Machine Learning Specialization',
    issuer:       'Coursera — Stanford / DeepLearning.AI',
    date:         'Mar 2024',
    expires:      'No Expiry',
    credentialId: 'COURSERA-ZZZZZZZ',
    url:          'https://coursera.org/verify/ZZZZZZZ',
    color:        '#00d4ff',
    category:     'AI / ML',
    skills:       ['Supervised Learning', 'Neural Networks', 'Python', 'TensorFlow'],
    logo:         '🤖',
  },
  {
    id: 4,
    title:        'Python for Everybody',
    issuer:       'Coursera — University of Michigan',
    date:         'Nov 2023',
    expires:      'No Expiry',
    credentialId: 'COURSERA-AAAAAAA',
    url:          'https://coursera.org/verify/AAAAAAA',
    color:        '#4db33d',
    category:     'Programming',
    skills:       ['Python', 'Data Structures', 'Web Scraping', 'Databases'],
    logo:         '🐍',
  },
  {
    id: 5,
    title:        'AWS Cloud Practitioner Essentials',
    issuer:       'Amazon Web Services',
    date:         'May 2024',
    expires:      'May 2027',
    credentialId: 'AWS-CLF-BBBBBBB',
    url:          'https://aws.amazon.com/verification',
    color:        '#ff9900',
    category:     'Cloud',
    skills:       ['AWS EC2', 'S3', 'Lambda', 'Cloud Architecture'],
    logo:         '☁️',
  },
  {
    id: 6,
    title:        'Git & GitHub Bootcamp',
    issuer:       'Udemy',
    date:         'Jun 2023',
    expires:      'No Expiry',
    credentialId: 'UC-CCCCCCCCCCC',
    url:          'https://udemy.com/certificate/UC-CCCCCCCCCCC',
    color:        '#f05032',
    category:     'Tools',
    skills:       ['Git', 'GitHub', 'Branching', 'CI/CD Basics'],
    logo:         '🔧',
  },
]

export const certCategories = ['All', 'Frontend', 'Full Stack', 'AI / ML', 'Programming', 'Cloud', 'Tools']