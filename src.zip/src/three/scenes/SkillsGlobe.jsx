import { Canvas } from '@react-three/fiber'
import { OrbitControls, Float } from '@react-three/drei'
import { EffectComposer, Bloom } from '@react-three/postprocessing'
import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { skills } from '../../data/skills'

function SkillDots() {
  const group = useRef()

  useFrame(({ clock }) => {
    if (group.current) {
      group.current.rotation.y = clock.getElapsedTime() * 0.15
    }
  })

  // Distribute skills on a sphere using Fibonacci sphere
  const points = skills.map((skill, i) => {
    const golden = Math.PI * (3 - Math.sqrt(5))
    const y = 1 - (i / (skills.length - 1)) * 2
    const r = Math.sqrt(1 - y * y)
    const theta = golden * i
    const radius = 2.5
    return {
      x: Math.cos(theta) * r * radius,
      y: y * radius,
      z: Math.sin(theta) * r * radius,
      skill,
    }
  })

  return (
    <group ref={group}>
      {/* Wireframe globe */}
      <mesh>
        <sphereGeometry args={[2.5, 24, 24]} />
        <meshStandardMaterial
          color="#915EFF"
          wireframe
          transparent
          opacity={0.08}
        />
      </mesh>

      {/* Skill dots */}
      {points.map(({ x, y, z, skill }) => (
        <Float key={skill.name} speed={2} floatIntensity={0.2}>
          <mesh position={[x, y, z]}>
            <sphereGeometry args={[0.1, 16, 16]} />
            <meshStandardMaterial
              color={skill.color}
              emissive={skill.color}
              emissiveIntensity={0.8}
              roughness={0}
              metalness={1}
            />
          </mesh>
        </Float>
      ))}
    </group>
  )
}

export default function SkillsGlobe() {
  return (
    <Canvas
      camera={{ position: [0, 0, 6], fov: 50 }}
      className="!absolute inset-0"
      gl={{ antialias: true, alpha: true }}
      dpr={[1, 2]}
    >
      <ambientLight intensity={0.5} />
      <pointLight position={[5, 5, 5]} color="#915EFF" intensity={2} />
      <pointLight position={[-5, -5, -5]} color="#00d4ff" intensity={1.5} />

      <SkillDots />

      <OrbitControls enableZoom={false} enablePan={false} />

      <EffectComposer>
        <Bloom luminanceThreshold={0.1} intensity={2} height={300} />
      </EffectComposer>
    </Canvas>
  )
}
