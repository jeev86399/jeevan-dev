import { motion } from 'framer-motion'

export default function Button({ children, variant = 'primary', href, onClick, className = '', ...props }) {
  const base = 'inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium text-sm transition-all duration-200 cursor-pointer'
  const variants = {
    primary: 'bg-gradient-to-r from-primary to-secondary text-white shadow-lg shadow-primary/30 hover:shadow-primary/50 hover:scale-105',
    outline: 'border border-primary/50 text-primary hover:bg-primary/10 hover:border-primary',
    ghost: 'text-white/70 hover:text-white hover:bg-white/5',
  }
  const cls = `${base} ${variants[variant]} ${className}`

  if (href) return (
    <motion.a whileTap={{ scale: 0.97 }} href={href} target="_blank" rel="noreferrer" className={cls} {...props}>
      {children}
    </motion.a>
  )

  return (
    <motion.button whileTap={{ scale: 0.97 }} onClick={onClick} className={cls} {...props}>
      {children}
    </motion.button>
  )
}
