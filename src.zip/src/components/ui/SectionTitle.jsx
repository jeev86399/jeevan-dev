import { motion } from 'framer-motion'
import { useInView } from '../../hooks/useInView'

export default function SectionTitle({ eyebrow, title, subtitle }) {
  const [ref, inView] = useInView()

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6 }}
      className="mb-14 text-center"
    >
      {eyebrow && (
        <p className="text-primary font-mono text-sm uppercase tracking-widest mb-3">{eyebrow}</p>
      )}
      <h2 className="font-display text-4xl sm:text-5xl font-bold text-white mb-4">{title}</h2>
      {subtitle && (
        <p className="text-white/50 max-w-xl mx-auto text-base">{subtitle}</p>
      )}
    </motion.div>
  )
}
