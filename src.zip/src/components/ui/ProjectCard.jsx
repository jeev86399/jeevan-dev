import { motion } from 'framer-motion'
import Badge from './Badge'
import Button from './Button'

export default function ProjectCard({ project, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -6 }}
      className="glass rounded-2xl overflow-hidden neon-border group"
    >
      {/* Image / color block */}
      <div
        className="h-44 w-full relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${project.color}22, #050816)` }}
      >
        <div
          className="absolute inset-0 opacity-20 group-hover:opacity-40 transition-opacity"
          style={{ background: `radial-gradient(circle at 50% 50%, ${project.color}, transparent 70%)` }}
        />
        {project.image && (
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
            loading="lazy"
          />
        )}
        <div className="absolute top-3 right-3">
          <span className="text-xs px-2 py-1 rounded-full glass text-white/70">{project.category}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 flex flex-col gap-4">
        <h3 className="font-display text-xl font-bold text-white group-hover:text-primary transition-colors">
          {project.title}
        </h3>
        <p className="text-white/60 text-sm leading-relaxed">{project.description}</p>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {project.tags.map(tag => (
            <Badge key={tag} label={tag} color={project.color} />
          ))}
        </div>

        {/* Links */}
        <div className="flex gap-3 mt-2">
          <Button href={project.github} variant="outline" className="text-xs px-4 py-2">
            GitHub ↗
          </Button>
          {project.live && (
            <Button href={project.live} variant="primary" className="text-xs px-4 py-2">
              Live Demo ↗
            </Button>
          )}
        </div>
      </div>
    </motion.div>
  )
}
