export default function Badge({ label, color }) {
  return (
    <span
      className="px-3 py-1 text-xs font-mono rounded-full border"
      style={{
        color: color || '#915EFF',
        borderColor: (color || '#915EFF') + '44',
        background: (color || '#915EFF') + '11',
      }}
    >
      {label}
    </span>
  )
}
