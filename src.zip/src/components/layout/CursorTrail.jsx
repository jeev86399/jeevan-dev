import { useEffect, useRef } from 'react'

export default function CursorTrail() {
  const dotRef = useRef(null)
  const ringRef = useRef(null)
  const pos = useRef({ x: 0, y: 0 })
  const ring = useRef({ x: 0, y: 0 })

  useEffect(() => {
    // Only show on desktop
    if (window.innerWidth < 768) return

    const dot = dotRef.current
    const ringEl = ringRef.current
    let rafId

    const move = (e) => {
      pos.current = { x: e.clientX, y: e.clientY }
    }
    window.addEventListener('mousemove', move)

    const animate = () => {
      // Dot follows instantly
      if (dot) {
        dot.style.transform = `translate(${pos.current.x - 4}px, ${pos.current.y - 4}px)`
      }
      // Ring lags behind (lerp)
      ring.current.x += (pos.current.x - ring.current.x) * 0.12
      ring.current.y += (pos.current.y - ring.current.y) * 0.12
      if (ringEl) {
        ringEl.style.transform = `translate(${ring.current.x - 16}px, ${ring.current.y - 16}px)`
      }
      rafId = requestAnimationFrame(animate)
    }
    rafId = requestAnimationFrame(animate)

    // Hover effects
    const addHover = () => ringEl?.classList.add('scale-150', 'opacity-50')
    const removeHover = () => ringEl?.classList.remove('scale-150', 'opacity-50')
    document.querySelectorAll('a, button').forEach(el => {
      el.addEventListener('mouseenter', addHover)
      el.addEventListener('mouseleave', removeHover)
    })

    return () => {
      window.removeEventListener('mousemove', move)
      cancelAnimationFrame(rafId)
    }
  }, [])

  return (
    <>
      {/* Tiny dot */}
      <div
        ref={dotRef}
        className="fixed top-0 left-0 w-2 h-2 rounded-full bg-primary pointer-events-none z-[9998] mix-blend-screen"
        style={{ willChange: 'transform' }}
      />
      {/* Lagging ring */}
      <div
        ref={ringRef}
        className="fixed top-0 left-0 w-8 h-8 rounded-full border border-primary/60 pointer-events-none z-[9997] transition-transform duration-75"
        style={{ willChange: 'transform' }}
      />
    </>
  )
}
