import { motion } from 'framer-motion'

export default function Loader() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[9999] bg-bg flex flex-col items-center justify-center gap-6"
    >
      {/* Spinning rings */}
      <div className="relative w-20 h-20">
        <div className="absolute inset-0 rounded-full border-2 border-primary/20 animate-spin" style={{ animationDuration: '3s' }} />
        <div className="absolute inset-2 rounded-full border-2 border-t-primary border-transparent animate-spin" style={{ animationDuration: '1.5s' }} />
        <div className="absolute inset-4 rounded-full border-2 border-b-secondary border-transparent animate-spin" style={{ animationDuration: '1s', animationDirection: 'reverse' }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-primary font-mono text-xs">3D</span>
        </div>
      </div>

      <div className="flex flex-col items-center gap-1">
        <motion.p
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="text-white/60 text-sm font-mono"
        >
          Initialising scene...
        </motion.p>
      </div>
    </motion.div>
  )
}
