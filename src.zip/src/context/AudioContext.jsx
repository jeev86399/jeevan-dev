import { createContext, useContext, useRef, useState } from 'react'

const AudioCtx = createContext()

/**
 * AudioProvider — wraps the app and exposes:
 *   audioEnabled   bool
 *   toggleAudio()  fn  — start / stop background ambient
 *   playClick()    fn  — short UI click sound
 *   playHover()    fn  — subtle hover tick
 *
 * Drop an ambient .mp3 in /public/audio/ambient.mp3
 * and a short click at /public/audio/click.mp3 to enable sounds.
 */
export function AudioProvider({ children }) {
  const [audioEnabled, setAudioEnabled] = useState(false)
  const ambientRef = useRef(null)

  const toggleAudio = () => {
    setAudioEnabled(prev => {
      const next = !prev
      if (next) {
        // lazy-create ambient audio
        if (!ambientRef.current) {
          ambientRef.current = new Audio('/audio/ambient.mp3')
          ambientRef.current.loop = true
          ambientRef.current.volume = 0.15
        }
        ambientRef.current.play().catch(() => {
          // Browser may block autoplay — that's fine
        })
      } else {
        ambientRef.current?.pause()
      }
      return next
    })
  }

  const playClick = () => {
    if (!audioEnabled) return
    const sfx = new Audio('/audio/click.mp3')
    sfx.volume = 0.4
    sfx.play().catch(() => {})
  }

  const playHover = () => {
    if (!audioEnabled) return
    const sfx = new Audio('/audio/hover.mp3')
    sfx.volume = 0.2
    sfx.play().catch(() => {})
  }

  return (
    <AudioCtx.Provider value={{ audioEnabled, toggleAudio, playClick, playHover }}>
      {children}
    </AudioCtx.Provider>
  )
}

export function useAudio() {
  const ctx = useContext(AudioCtx)
  if (!ctx) throw new Error('useAudio must be used inside AudioProvider')
  return ctx
}
