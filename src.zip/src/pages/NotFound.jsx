import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

export default function NotFound() {
  return (
    <main className="bg-bg min-h-screen flex flex-col items-center justify-center text-center px-6">
      <motion.p
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="font-display text-[10rem] font-bold gradient-text leading-none"
      >
        404
      </motion.p>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-white/50 text-lg mb-8"
      >
        This page doesn't exist in this dimension.
      </motion.p>
      <Link
        to="/"
        className="px-6 py-3 bg-gradient-to-r from-primary to-secondary rounded-full text-white font-medium hover:scale-105 transition-transform"
      >
        ← Back to Home
      </Link>
    </main>
  )
}
