import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { Suspense, lazy, useEffect } from 'react'
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'
import Loader from './components/layout/Loader'
import CursorTrail from './components/layout/CursorTrail'
import './App.css'
import ChatBot from './components/ui/ChatBot'

const Home     = lazy(() => import('./pages/Home'))
const About    = lazy(() => import('./pages/About'))
const Projects = lazy(() => import('./pages/Projects'))
const Skills   = lazy(() => import('./pages/Skills'))
const Contact  = lazy(() => import('./pages/Contact'))
const NotFound = lazy(() => import('./pages/NotFound'))

/**
 * Locks body scroll only on "/" (Home uses ScrollControls).
 * All other pages get normal browser scroll back.
 */
function ScrollManager() {
  const { pathname } = useLocation()

  useEffect(() => {
    if (pathname === '/') {
      document.body.classList.add('scroll-locked')
    } else {
      document.body.classList.remove('scroll-locked')
    }
    // Cleanup when component unmounts
    return () => document.body.classList.remove('scroll-locked')
  }, [pathname])

  return null
}

function FooterConditional() {
  const { pathname } = useLocation()
  return pathname === '/' ? null : <Footer />
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollManager />
      <CursorTrail />
      <Navbar />
      <Suspense fallback={<Loader />}>
        <Routes>
          <Route path="/"         element={<Home />} />
          <Route path="/about"    element={<About />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/skills"   element={<Skills />} />
          <Route path="/contact"  element={<Contact />} />
          <Route path="*"         element={<NotFound />} />
        </Routes>
      </Suspense>
      <FooterConditional />
      <ChatBot />
    </BrowserRouter>
  )
}